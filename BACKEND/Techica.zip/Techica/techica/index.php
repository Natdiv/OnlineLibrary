<?php
    header('Location: view-app/index.php');
?>